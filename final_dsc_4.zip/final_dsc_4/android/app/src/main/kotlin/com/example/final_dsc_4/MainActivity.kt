package com.example.final_dsc_4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
